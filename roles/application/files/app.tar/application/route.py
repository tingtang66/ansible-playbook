from handlers.homepage import IndexHandler
route = []
route.append((r'/', IndexHandler))