from tornado.web import RequestHandler

class NasaDailyHandler(RequestHandler):
	def get(self):
		pass